package com.yourname.volcam;

import android.app.Activity;
import android.hardware.Camera;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;
import android.widget.VideoView;
import java.io.IOException;

public class MainActivity extends Activity {

    private Camera camera;
    private SurfaceView cameraPreview;
    private VideoView spoofVideo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        cameraPreview = (SurfaceView) findViewById(R.id.cameraPreview);
        spoofVideo = (VideoView) findViewById(R.id.spoofVideo);

        String uriPath = "android.resource://" + getPackageName() + "/" + R.raw.spoof_video;
        spoofVideo.setVideoURI(Uri.parse(uriPath));

        spoofVideo.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                spoofVideo.start();
            }
        });

        Button btnReal = (Button) findViewById(R.id.btnReal);
        btnReal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showRealCamera();
            }
        });

        Button btnSpoof = (Button) findViewById(R.id.btnSpoof);
        btnSpoof.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showSpoofVideo();
            }
        });
    }

    private void showRealCamera() {
        spoofVideo.stopPlayback();
        spoofVideo.setVisibility(View.GONE);
        cameraPreview.setVisibility(View.VISIBLE);

        try {
            camera = Camera.open(1); // 1 is the front camera
            camera.setPreviewDisplay(cameraPreview.getHolder());
            camera.startPreview();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void showSpoofVideo() {
        if (camera != null) {
            camera.stopPreview();
            camera.release();
            camera = null;
        }
        cameraPreview.setVisibility(View.GONE);
        spoofVideo.setVisibility(View.VISIBLE);
        spoofVideo.start();
    }
}